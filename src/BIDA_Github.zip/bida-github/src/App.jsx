import React, { useState, useEffect } from "react";
import AppFinal    from "./App_FINAL.jsx";
import LoginScreen from "./components/LoginScreen.jsx";
import MemberDashboard from "./components/MemberDashboard.jsx";

export default function App() {
  const [session, setSession] = useState(() => {
    try {
      const raw = sessionStorage.getItem("bida_sess");
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (Date.now() > s.exp) { sessionStorage.removeItem("bida_sess"); return null; }
      return s;
    } catch { return null; }
  });
  const [showLogin, setShowLogin] = useState(false);

  // 30-min idle logout for members
  useEffect(() => {
    if (!session) return;
    let t;
    const reset = () => { clearTimeout(t); t = setTimeout(doLogout, 30*60*1000); };
    ["mousedown","keydown","touchstart","scroll"].forEach(e => window.addEventListener(e, reset, {passive:true}));
    reset();
    return () => { clearTimeout(t); ["mousedown","keydown","touchstart","scroll"].forEach(e => window.removeEventListener(e, reset)); };
  }, [session]);

  const doLogin = (s) => {
    const full = {...s, exp: Date.now()+8*3600*1000};
    sessionStorage.setItem("bida_sess", JSON.stringify(full));
    setSession(full); setShowLogin(false);
  };
  const doLogout = () => { sessionStorage.removeItem("bida_sess"); setSession(null); setShowLogin(false); };

  if (showLogin && !session) return <LoginScreen onLogin={doLogin} onBack={() => setShowLogin(false)} />;
  if (session)               return <MemberDashboard session={session} onLogout={doLogout} />;

  return (
    <>
      <div style={{background:"#0d47a1",color:"#fff",padding:"5px 16px",display:"flex",alignItems:"center",justifyContent:"center",gap:14,fontSize:11}}>
        <span style={{opacity:.75}}>BIDA Member Portal</span>
        <button onClick={()=>setShowLogin(true)} style={{background:"#fff",color:"#0d47a1",border:"none",borderRadius:6,padding:"3px 12px",fontWeight:700,fontSize:11,cursor:"pointer"}}>
          Member Login →
        </button>
      </div>
      <AppFinal />
    </>
  );
}
